namespace WorkflowAppWPF.Models
{
    public class WorkflowApplication
    {
        public int ID{get;set;}
        public string APPTITLE{get;set;}
        public string APPCONTENT{get;set;}
        public string NAME{get;set;}
        public int STATUS{get;set;}
        public int DELETE_FLAG{get;set;}
        public DateTime CREATED_AT{get;set;}
    }
}