using System.Windows;
using System.Windows.Input;
using WorkflowAppWPF.Commands;

namespace WorkflowAppWPF.ViewModels
{
    public class MainViewModel : ViewModelBase//共通化
    {
        //画面遷移先のViewModelを持つ
        private ViewModelBase _currentViewModel;

        //画面遷移ボタン押下→メソッド実行で変更されていく、
        //そのあとDataTemplateの影響で画面遷移処理が成り立つ
        public ViewModelBase CurrentViewModel
        {
            get => _currentViewModel;
            set
            {
                _currentViewModel = value;
                OnPropertyChanged();
            }
        }
        public MainViewModel()
        {
            // 最初に表示する画面
            CurrentViewModel = new MenuViewModel(this);//MainViewModel
        }

    }
}