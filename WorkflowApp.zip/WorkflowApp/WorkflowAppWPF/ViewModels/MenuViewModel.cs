using System.Windows;
using System.Windows.Input;
using WorkflowAppWPF.Commands;
using WorkflowAppWPF.Views;

namespace WorkflowAppWPF.ViewModels
{
    public class MenuViewModel : ViewModelBase//共通化
    {
        //フィールド
        private readonly MainViewModel _mainViewModel;//書き換え不可,親ViewModelを保持
        public ICommand OpenRegistrationCommand{get;}//申請登録ボタン
        public ICommand OpenAppCommand{get;}//申請一覧ボタン

        //コンストラクタ
        public MenuViewModel(MainViewModel mainViewModel)
        {
            _mainViewModel = mainViewModel;

            //RelayCommandの呼び出し
            OpenRegistrationCommand = new RelayCommand(OpenRegistration);
            OpenAppCommand = new RelayCommand(OpenApp);
        }

        //メソッド
        //申請登録画面遷移
        private void OpenRegistration()
        {
            _mainViewModel.CurrentViewModel =new RegistrationViewModel(_mainViewModel);
        }

        //申請一覧画面遷移
        private void OpenApp()
        {
            _mainViewModel.CurrentViewModel =new AppViewModel(_mainViewModel);
        }
    }
}
