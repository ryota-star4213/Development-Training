using System.Windows;
using System.Windows.Input;
using WorkflowAppWPF.Commands;
using WorkflowAppWPF.Services;

namespace WorkflowAppWPF.ViewModels
{
    public class RegistrationViewModel : ViewModelBase//共通化
    {
        //フィールド
        private readonly MainViewModel _mainViewModel;//親ViewModelを保持

        private readonly AppService _appService = new AppService();//Service（WPF）を保持

        private string _appName;
        public string AppName//ユーザーが入力した申請者名
        {
            get => _appName;
            set{ _appName = value;}
        }

        private string _apptitle;
        public string AppTitle//ユーザーが入力した申請タイトル
        {
            get => _apptitle;
            set{_apptitle = value;}
        }

        private string _appcontent;
        public string AppContent//ユーザーが入力した申請内容
        {
            get => _appcontent;
            set{_appcontent = value;}
        }

        public ICommand RegistrationAppCommand{get;}//登録ボタン
        public ICommand BackToMenuCommand{get;}//メニューへ戻るボタン

        // コンストラクタ
        public RegistrationViewModel(MainViewModel mainViewModel)
        {
            _mainViewModel = mainViewModel;

            //RelayCommandの呼び出し
            RegistrationAppCommand = new RelayCommand(RegistrationApp);
            BackToMenuCommand = new RelayCommand(BackToMenu);
        }

        // メソッド
        //メニューへ戻るボタンクリック時、メニューへ画面遷移するメソッド
        private void BackToMenu()
        {
            _mainViewModel.CurrentViewModel =new MenuViewModel(_mainViewModel);
        }

        //登録ボタンクリック時API呼び出し(RegistrationServiceに)をお願いするメソッド
        private async void RegistrationApp()
        {
            //Service(WPF)を呼び出し
            var result = await _appService.CreateAsync(AppName,AppTitle,AppContent);

            //レスポンス結果を確認
            if (!result.Success)//失敗の場合
            {
                MessageBox.Show(result.Message);
                return;//登録ボタンクリック前の状態に戻す
            }
            else//成功の場合
            {
                MessageBox.Show(result.Message);
                BackToMenu();//メニューへ遷移
            }
        }
    }
}