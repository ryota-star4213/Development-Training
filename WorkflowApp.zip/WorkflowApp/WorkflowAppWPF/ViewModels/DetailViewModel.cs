using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Input;
using WorkflowAppWPF.Commands;
using WorkflowAppWPF.Models;
using WorkflowAppWPF.Services;

namespace WorkflowAppWPF.ViewModels
{
    public class DetailViewModel : ViewModelBase//共通化
    {

        //フィールド
        public string STATUSSTR ;
        private readonly MainViewModel _mainViewModel;//書き換え不可

        private readonly AppService _appService = new AppService();//書き換え不可

        public ObservableCollection<WorkflowApplication> DitailDataGrid { get; set; }
                = new ObservableCollection<WorkflowApplication>();//申請詳細のデータを持つ

        private WorkflowApplication _selectedApp;//選択された申請
        public WorkflowApplication SelectedApp
        {
            get => _selectedApp;
            set
            {
                _selectedApp = value;
                OnPropertyChanged();//UIに変更を通知
            }
        }

        private string _statusName;//選択された申請
        public string StatusName
        {
            get
            {
                return SelectedApp.STATUS switch 
                {
                    0 => "申請中",
                    1 => "承認済",
                    2 => "差戻し",
                    _ => "不明"
                };
            }
        }

        public ICommand BackToMenuCommand{get;}//メニューへ戻るボタン
        public ICommand OpenAppCommand{get;}//申請一覧ボタン
        public ICommand ChangeApprovalCommand{get;}//承認ボタン
        public ICommand ChangeRejectCommand{get;}//差戻しボタン

        //コンストラクタ
        public DetailViewModel(MainViewModel mainViewModel,WorkflowApplication selectedApp)
        {
            _mainViewModel = mainViewModel;
            SelectedApp = selectedApp;//選択された申請（申請一覧から送られてきた）             

            //RelayCommandの呼び出し
            BackToMenuCommand = new RelayCommand(BackToMenu);
            OpenAppCommand = new RelayCommand(OpenApp);
            ChangeApprovalCommand = new RelayCommand(ChangeApproval);
            ChangeRejectCommand = new RelayCommand(ChangeReject);
        }
        
        //メソッド
        //メニューへ戻るボタンクリック時のメニュー画面遷移処理
        private void BackToMenu()
        {
            _mainViewModel.CurrentViewModel =new MenuViewModel(_mainViewModel);
        }

        //申請一覧へボタンクリック時の申請一覧画面遷移処理
        private void OpenApp()
        {
            _mainViewModel.CurrentViewModel =new AppViewModel(_mainViewModel);
        }

        //ステータスを承認に変更するAPIの呼び出し
        private async void ChangeApproval()
        {
            if (SelectedApp == null)//未選択をはじく
            {
                MessageBox.Show("ステータス変更する申請を選択してください");
                return;
            }else if (SelectedApp.STATUS == 1)//ステータス重複をはじく
            {
                MessageBox.Show("すでに承認済みです");
                return;
            }

            //ステータス変更確認ダイアログ表示
            MessageBoxResult MessageBoxResult = MessageBox.Show(
                "ステータスを\"承認\"に変更しますか？","確認",//メッセージとタイトル
                MessageBoxButton.YesNo,//ボタンのパターン
                MessageBoxImage.Question//アイコン表示
            );

            //いいえを選んだ場合ステータス変更処理終了させる
            if(MessageBoxResult != MessageBoxResult.Yes)
            {
                return;
            }
            //APIにリクエスト送信し、レスポンス結果を取得
            var result = await _appService.ApproveAsync(SelectedApp.ID);//選択した申請IDを送信

            //レスポンス結果を確認
            if (!result.Success)//失敗の場合
            {
                MessageBox.Show(result.Message);
                return;//更新ボタンクリック前の状態に戻す
            }
            else//成功の場合
            {
                SelectedApp.STATUS = 1;//選択した申請のステータスを２に変更
                OnPropertyChanged(nameof(StatusName));//選択された行のUI更新
                MessageBox.Show(result.Message);
            }
        }

        //ステータスを差戻しに変更するAPIの呼び出し
        private async void ChangeReject()
        {
            if (SelectedApp == null)//未選択をはじく
            {
                MessageBox.Show("ステータス変更する申請を選択してください");
                return;
            }else if (SelectedApp.STATUS == 2)//ステータスの重複をはじく
            {
                MessageBox.Show("すでに差戻し済みです");
                return;
            }

            //ステータス変更確認ダイアログ表示
            MessageBoxResult MessageBoxResult = MessageBox.Show(
                "ステータスを\"差戻り\"に変更しますか？","確認",//メッセージとタイトル
                MessageBoxButton.YesNo,//ボタンのパターン
                MessageBoxImage.Question//アイコン表示
            );

            //いいえを選んだ場合ステータス変更処理終了させる
            if(MessageBoxResult != MessageBoxResult.Yes)
            {
                return;
            }

            //APIにリクエスト送信し、レスポンス結果を取得
            var result = await _appService.RejectAsync(SelectedApp.ID);//選択した申請IDを送信

            //レスポンス結果を確認
            if (!result.Success)//失敗の場合
            {
                MessageBox.Show(result.Message);
                return;//更新ボタンクリック前の状態に戻す
            }
            else//成功の場合
            {
                SelectedApp.STATUS = 2;//選択した申請のステータスを２に変更
                OnPropertyChanged(nameof(StatusName));//選択された行のUI更新
                MessageBox.Show(result.Message);
            }
        }
    }
}