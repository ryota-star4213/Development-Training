using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Input;
using WorkflowAppWPF.Commands;
using WorkflowAppWPF.Services;
using WorkflowAppWPF.Models;

namespace WorkflowAppWPF.ViewModels
{
    public class AppViewModel : ViewModelBase//共通化
    {

        //フィールド
        //親ViewModelを保持
        private readonly MainViewModel _mainViewModel;//書き換え不可

        //Service（WPF）を保持
        private readonly AppService _appService = new AppService();//書き換え不可

        //申請一覧データを持つ
        public ObservableCollection<WorkflowApplication> AppDataGrid{ get; set; }
            = new ObservableCollection<WorkflowApplication>();

        private WorkflowApplication _selectedApp;
        public WorkflowApplication SelectedApp//選択された行の情報を持つ
        {
            get => _selectedApp;
            set
            {
                _selectedApp = value;
                OnPropertyChanged();
            }
        }
        
        public ICommand BackToMenuCommand{get;}//メニューへ戻るボタン
        public ICommand OpenDetailCommand{get;}//申請詳細ボタン
        public ICommand DeleteAppCommand{get;}//削除ボタン

        //コンストラクタ
        public AppViewModel(MainViewModel mainViewModel)
        {
            _mainViewModel = mainViewModel;

            //RelayCommandの呼び出し
            BackToMenuCommand = new RelayCommand(BackToMenu);
            OpenDetailCommand = new RelayCommand(OpenDetail);
            DeleteAppCommand = new RelayCommand(DeleteApp);
            _ = LoadAppList();
        }

        //メニュー画面遷移処理
        private void BackToMenu()
        {
            _mainViewModel.CurrentViewModel =new MenuViewModel(_mainViewModel);
        }

        //申請詳細画面遷移処理
        private void OpenDetail()
        {
            if (SelectedApp == null)//未選択をはじく
            {
                MessageBox.Show("詳細表示する申請を選択してください");
                return ;
            }

            //申請一覧画面へ処理(選択した申請のデータを送る)
            _mainViewModel.CurrentViewModel =new DetailViewModel(_mainViewModel,SelectedApp);
        }

        //申請一覧取得処理（開始）
        private async Task LoadAppList()
        {
            //Service(WPF)呼び出し
            var result = await _appService.GetAllAsync();

            //レスポンス結果を確認
            if (!result.Success)
            {
                MessageBox.Show(result.Message);
                return;
            }

            //申請一覧をクリア
            AppDataGrid.Clear();

            //申請一覧を再構築
            foreach (var app in result.appList)
            {
                AppDataGrid.Add(app);
            }
        }

        //削除処理（開始）
        private async void DeleteApp()
        {
            if (SelectedApp == null)//未選択はじく
            {
                MessageBox.Show("削除する申請を選択してください");
                return ;
            }

            //削除確認ダイアログ表示
            MessageBoxResult messageBoxResult = MessageBox.Show(
                $"{SelectedApp.NAME}を削除しますか？","確認",//メッセージとタイトル
                MessageBoxButton.YesNo,//ボタンのパターン
                MessageBoxImage.Warning//アイコン表示
            );

            //いいえを選んだ場合削除処理終了させる
            if(messageBoxResult != MessageBoxResult.Yes)
            {
                return;
            }

            //Service(WPF)呼び出し(選択された申請IDを送る)
            var result = await _appService.DeleteAsync(SelectedApp.ID);

            //レスポンス結果を確認
            if (!result.Success)//失敗の場合
            {
                MessageBox.Show(result.Message);
                return;//削除ボタンクリック前の状態に戻す
            }
            else//成功の場合
            {
                AppDataGrid.Remove(SelectedApp);//申請一覧から削除（自動更新）
                MessageBox.Show(result.Message);
            }
        }
    }
}