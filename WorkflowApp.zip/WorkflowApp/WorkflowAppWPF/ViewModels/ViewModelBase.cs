using System.ComponentModel;
using System.Runtime.CompilerServices;

public class ViewModelBase : INotifyPropertyChanged
{
    public event PropertyChangedEventHandler PropertyChanged;

    //UIに変更を通知するメソッド（基本定型文）
    public void OnPropertyChanged([CallerMemberName] string name = null)
    {
        //PropertyChangedがnullでなければ
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }
}
