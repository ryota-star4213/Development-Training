@echo off
chcp 65001

echo ============================
echo WPF アプリ起動
echo ============================

cd WorkflowAppWPF

echo [dotnet run 実行]
dotnet run

pause
