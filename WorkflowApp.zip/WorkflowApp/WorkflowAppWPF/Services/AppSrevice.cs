using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Windows;
using WorkflowAppWPF.Models;
using System.Collections.ObjectModel;

namespace WorkflowAppWPF.Services
{
    public class AppService
    {

        private readonly HttpClient _client = new HttpClient();//クラス内共通化、書き換え不可
        
        //登録APIの呼び出しメソッド
        public async Task<(bool Success, string Message)> CreateAsync(
            string appName,//申請者名
            string title,  //申請タイトル
            string content)//申請内容
        {
            //入力チェック
            if (string.IsNullOrWhiteSpace(appName))
            {
                return (false, "申請者名を入力してください");
            }else if (string.IsNullOrWhiteSpace(title))
            {
                return (false, "タイトルを入力してください");
            }else if (string.IsNullOrWhiteSpace(content))
            {
                return (false, "内容を入力してください");
            }

            //APIに送る登録情報をまとめる
            var registorationAppData = new
            {
                applicant_name = appName,//申請者名
                apptitle = title,           //申請タイトル
                appcontent = content        //申請内容
            };

            //登録情報をjsonファイル化
            var json = JsonSerializer.Serialize(registorationAppData);
            
            //設定情報をまとめる
            var contentData = new StringContent(json, Encoding.UTF8, "application/json");

            //API呼び出し
            try
            {
                //POST呼び出し
                var response = await _client.PostAsync(
                    "http://localhost:3000/application",contentData);

                //レスポンス結果の確認
                if (!response.IsSuccessStatusCode)
                {
                    return (false, "申請の登録に失敗しました");//API失敗情報を返す
                }
                else
                {
                    return (true, "申請を登録しました");//API成功情報を返す
                }
            }
            catch (Exception ex)
            {
                return (false, $"通信エラー: {ex.Message}");
            }
        }

        //論理削除（更新）のAPI呼び出しメソッド
        public async Task<(bool Success, string Message)> DeleteAsync(int id)
        {
            if (id == 0)
            {
                return (false, "削除する申請を選択してください");
            }

            var deleteAppData = new
            {
                deleteid = id,
            };

            //削除する申請idをjsonファイル化
            var json = JsonSerializer.Serialize(deleteAppData);

            //設定情報をまとめる
            var contentData = new StringContent(json, Encoding.UTF8, "application/json");

            try
            {
                //PUT呼び出し
                var response = await _client.PutAsync(
                    $"http://localhost:3000/application/delete/{id}",contentData);

                //レスポンス結果の確認
                if (!response.IsSuccessStatusCode)
                {
                    return (false, "削除に失敗しました");//API失敗情報を返す
                }
                else
                {
                    return (true, "削除しました");//API成功情報を返す
                }
            }
            catch (Exception ex)
            {
                return (false, $"通信エラー: {ex.Message}");
            }

        }

        //申請ステータス変更（承認）のAPI呼び出しメソッド
        public async Task<(bool Success, string Message)> ApproveAsync(int id)
        {
            if (id == 0)
            {
                return (false, "ステータス変更をする申請を選択してください");
            }

             int status = 1;

            var updataAppData = new
            {
                updataid = id,
                appstatus = status
            };

            //ステータス変更する申請idをjsonファイル化
            var json = JsonSerializer.Serialize(updataAppData);

            //設定情報をまとめる
            var contentData = new StringContent(json, Encoding.UTF8, "application/json");

            try
            {
                //PUT呼び出し
                var response = await _client.PutAsync(
                    $"http://localhost:3000/application/approve/{id}",contentData);

                //レスポンス結果の確認
                if (!response.IsSuccessStatusCode)
                {
                    return (false, "ステータス変更に失敗しました");//API失敗情報を返す
                }
                else
                {
                    return (true, "ステータスを変更しました");//API成功情報を返す
                }
            }catch(Exception ex)
            {
                return (false, $"通信エラー: {ex.Message}");
            }

        }

        //申請ステータス変更（差戻し）のAPI呼び出しメソッド
        public async Task<(bool Success, string Message)> RejectAsync(int id)
        {
            if (id == 0)
            {
                return (false, "ステータス変更をする申請を選択してください");
            }

            int status = 2;

            var updataAppData = new
            {
                updataid = id,
                appstatus = status
            };

            //ステータス変更する申請idをjsonファイル化
            var json = JsonSerializer.Serialize(updataAppData);

            //設定情報をまとめる
            var contentData = new StringContent(json, Encoding.UTF8, "application/json");

            try
            {
                //PUT呼び出し
                var response = await _client.PutAsync(
                    $"http://localhost:3000/application/reject/{id}",contentData);

                //レスポンス結果の確認
                if (!response.IsSuccessStatusCode)
                {
                    return (false, "ステータス変更に失敗しました");//API失敗情報を返す
                }
                else
                {
                    return (true, "ステータスを変更しました");//API成功情報を返す
                }
            }
            catch (Exception ex)
            {
                return (false, $"通信エラー: {ex.Message}");
            }

        }

        //申請取得のAPI呼び出しメソッド
        public async Task<(bool Success, string Message , ObservableCollection<WorkflowApplication> appList)> GetAllAsync()
        {
            try
            {
                //Get呼び出し
                var response = await _client.GetAsync("http://localhost:3000/application");

                if (response.IsSuccessStatusCode)
                {
                    //レスポンスのJSONをstringとして読む　※非同期処理
                    var json = await response.Content.ReadAsStringAsync();
                    
                    var options = new JsonSerializerOptions
                    {
                        PropertyNameCaseInsensitive = true
                    };

                    //C#で使えるようにオブジェクトに変換（ObservableCollection<WorkflowApplication>化）
                    var appList = JsonSerializer.Deserialize<ObservableCollection<WorkflowApplication>>(json, options);
                    
                    return (true, "申請の取得が成功しました" , appList);
                }
                else
                {
                    return (false, "申請の取得が失敗しました", null);
                }
            }catch(Exception ex)
            {
                return (false, $"通信エラー: {ex.Message}",null);
            }
        }
    }
}
