using System.Windows;
using System.Windows.Controls;
using WorkflowAppWPF.ViewModels;


namespace WorkflowAppWPF.Views
{
    // public partial class AppView : UserControl
    public partial class AppView
    {
        public AppView()
        {
            InitializeComponent();
        }
    }
}