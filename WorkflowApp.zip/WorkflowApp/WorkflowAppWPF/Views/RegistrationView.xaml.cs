using System.Windows;
using WorkflowAppWPF.ViewModels;
using System.Windows.Controls;

namespace WorkflowAppWPF.Views
{
    // public partial class RegistrationView : UserControl
    public partial class RegistrationView
    {
        public RegistrationView()
        {
            InitializeComponent();
        }
    }
}