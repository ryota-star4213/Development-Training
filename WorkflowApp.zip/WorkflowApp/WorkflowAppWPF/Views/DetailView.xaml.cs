using System.Windows;
using WorkflowAppWPF.ViewModels;
using System.Windows.Controls;

namespace WorkflowAppWPF.Views
{
    // public partial class DetailView : UserControl
    public partial class DetailView
    {
        public DetailView()
        {
            InitializeComponent();
        }
    }
}