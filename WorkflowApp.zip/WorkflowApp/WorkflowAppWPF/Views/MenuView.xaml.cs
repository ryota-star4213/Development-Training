using System.Windows;
using WorkflowAppWPF.ViewModels;
using System.Windows.Controls;

namespace WorkflowAppWPF.Views
{
    // public partial class MenuView : UserControl
    public partial class MenuView
    {
        public MenuView()
        {
            InitializeComponent();

        }
    }
}
