using System;
using System.Windows.Input;

namespace WorkflowAppWPF.Commands
{
    public class RelayCommand : ICommand
    {
        private readonly Action _execute;

        //コンストラクタ（基本定型文）
        //コマンド実装している画面への遷移時（コンストラクタ時に）に動作し、
        //実行したい処理が引数で送られてくるので処理を保存
        public RelayCommand(Action execute)
        {
            _execute = execute;
        }

        public bool CanExecute(object parameter) => true;

        //コマンドボタンクリック時に動作し、引数に設定したメソッドが実行される
        public void Execute(object parameter)
        {
            _execute();
        }

        public event EventHandler CanExecuteChanged;
    }

}