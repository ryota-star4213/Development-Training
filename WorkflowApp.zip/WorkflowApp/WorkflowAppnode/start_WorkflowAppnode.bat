@echo off
chcp 65001

echo ============================
echo Node.js API 起動
echo ============================

cd WorkflowAppnode

echo [Node.js 起動]
node app.js

pause
