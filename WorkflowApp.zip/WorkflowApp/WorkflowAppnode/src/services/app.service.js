const repository = require("../repository/app.repository");

async function getAllApp() {
  return await repository.selectAll();
}

async function createApp(apptitle, appcontent, applicantName) {

  if (!apptitle || !appcontent || !applicantName) {
    throw new Error("取得値エラー");
  }

  return await repository.insertApp( apptitle , appcontent, applicantName );
}

async function approveApp(updataid,appstatus) {

  if (!updataid || !appstatus) {
    throw new Error("取得値エラー");
  }

  return await repository.updateStatus(updataid,appstatus);
}

async function rejectApp(updataid,appstatus) {

  if (!updataid || !appstatus) {
    throw new Error("取得値エラー");
  }

  return await repository.updateStatus(updataid,appstatus);
}

async function deleteApp(deleteid) {

  if (!deleteid) {
    throw new Error("取得値エラー");
  }

  return await repository.logicalDelete(deleteid);
}

module.exports = {getAllApp,createApp,approveApp,rejectApp,deleteApp};
