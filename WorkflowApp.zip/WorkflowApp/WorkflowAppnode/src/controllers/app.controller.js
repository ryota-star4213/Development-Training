const service = require("../services/app.service");

async function getAll(req, res) {
  try {
    result = await service.getAllApp();
    res.status(200).json(result.rows);

  } catch (err) {
    console.error("Controllerエラー:", err);

    res.status(400).json({ error: err.message });
  }
}

async function create(req, res) {
  try {
    const { apptitle, appcontent, applicant_name } = req.body;

    await service.createApp( apptitle , appcontent , applicant_name );

    res.status(201).json({ message: "DB登録成功" });

  } catch (err) {
    console.error("Controllerエラー:", err);

    res.status(400).json({ error: err.message });
  }
}

async function approve(req, res) {
  try {
    const { updataid,appstatus } = req.body;

    await service.approveApp(updataid,appstatus);

    res.status(200).json({ message: "DB更新成功" });

  } catch (err) {
    console.error("Controllerエラー:", err);

    res.status(400).json({ error: err.message });
  }
}

async function reject(req, res) {
  try {
    const { updataid,appstatus } = req.body;

    await service.rejectApp(updataid,appstatus);

    res.status(200).json({ message: "DB更新成功" });

  } catch (err) {
    console.error("Controllerエラー:", err);

    res.status(400).json({ error: err.message });
  }
}

async function logocalDelete(req, res) {
  try {
    const { deleteid } = req.body;

    await service.deleteApp( deleteid );

    res.status(200).json({ message: "DB論理削除成功" });

  } catch (err) {
    console.error("Controllerエラー:", err);

    res.status(400).json({ error: err.message });
  }
}

module.exports = {create,getAll,approve,reject,logocalDelete};
