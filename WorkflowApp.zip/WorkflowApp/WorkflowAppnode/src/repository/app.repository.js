const { getConnection } = require("../db/oracle");

async function selectAll() {
  let connection;

  try {
    connection = await getConnection();

    const sql = `
     SELECT * FROM APPLICATIONS WHERE delete_flag = 0
    `;

    const result = await connection.execute( sql );
    //データを渡さなきゃ
    return result;

  } catch (err) {
    console.error("Repositoryエラー:", err);
    throw err;

  } finally {
    if (connection) {
      await connection.close();
    }
  }
}

async function insertApp(apptitle, appcontent, applicantName) {
  let connection;

  try {
    connection = await getConnection();

    const sql = `
      INSERT INTO APPLICATIONS
      (apptitle, appcontent, name)
      VALUES (:apptitle, :appcontent, :applicantName)
    `;

    const result = await connection.execute(
      sql,
      { apptitle, appcontent, applicantName },
      { autoCommit: true }
    );

    return result;

  } catch (err) {
    console.error("Repositoryエラー:", err);
    throw err;

  } finally {
    if (connection) {
      await connection.close();
    }
  }
}

async function updateStatus(updataid,appstatus) {
  let connection;

  try {
    connection = await getConnection();

    const sql = `
      UPDATE APPLICATIONS SET status = :appstatus WHERE id = :updataid
    `;

    const result = await connection.execute(
      sql,
      { appstatus,updataid },
      { autoCommit: true }
    );

    return result;

  } catch (err) {
    console.error("Repositoryエラー:", err);
    throw err;

  } finally {
    if (connection) {
      await connection.close();
    }
  }
}

async function logicalDelete(deleteid) {
  let connection;

  try {
    connection = await getConnection();

    const sql = `
      UPDATE APPLICATIONS SET delete_flag = 1 WHERE id = :deleteid
    `;

    const result = await connection.execute(
      sql,
      { deleteid },
      { autoCommit: true }
    );

    return result;

  } catch (err) {
    console.error("Repositoryエラー:", err);
    throw err;

  } finally {
    if (connection) {
      await connection.close();
    }
  }
}
module.exports = {selectAll,insertApp,updateStatus,logicalDelete};
