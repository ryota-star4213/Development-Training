const express = require("express");
const controller = require("../controllers/app.controller");

const router = express.Router();

//postだけすべて完了
router.get("/application", controller.getAll);
router.post("/application", controller.create);
router.put("/application/approve/:id", controller.approve);
router.put("/application/reject/:id", controller.reject);
router.put("/application/delete/:id", controller.logocalDelete);

module.exports = router;
