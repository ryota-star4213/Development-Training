const express = require("express");
const app = express();

app.use(express.json());

const routes = require("./src/routes/app.routes");
app.use(routes);

app.listen(3000, () => {
  console.log("API起動: http://localhost:3000");
});
