@echo off
chcp 65001

echo ============================
echo ワークフローアプリ 起動
echo ============================

REM API 起動
echo [API 起動]
start "ワークフローAPI起動" "C:\Users\SST52\WorkflowApp\WorkflowAppnode\start_WorkflowAppnode.bat"

REM 少し待つ（API起動待ち）
timeout /t 3 >nul

REM WPF 起動
echo [WPF 起動]
start "ワークフローWPF起動" "C:\Users\SST52\WorkflowApp\WorkflowAppWPF\start_WorkflowAppWPF.bat"

echo ============================
echo 起動完了
echo ============================

pause
