@echo off
chcp 65001

echo ============================
echo Node.js API 起動
echo ============================

cd /d %~dp0

echo [npm install 実行]
call npm install

echo [Node.js 起動]
node app.js

pause
