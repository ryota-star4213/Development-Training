//oracledb.js（DB接続）

//Olacleライブラリの読み込み
const oracledb = require("oracledb");

//取得結果の形式を指定する（列名付きのオブジェクト化）
oracledb.outFormat = oracledb.OUT_FORMAT_OBJECT;

//DB接続メソッド　※非同期処理の宣言
async function getConnection() {
  //非同期処理
  return await oracledb.getConnection({
    //DB接続情報
    user: "SYSTEM",
    password: "admin",
    connectString: "localhost:1521/XEPDB1"//1521はOracleのポート
  });
}

//ほかのファイルから使えるように外部に公開
module.exports = { getConnection };
