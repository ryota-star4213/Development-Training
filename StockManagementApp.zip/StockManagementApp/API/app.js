//app.js（設定）

//Expressの読み込み
const express = require("express");

//在庫API（ルーターのinventory.js）を読み込み
const inventoryRouter = require("./routes/inventory");

//サーバー作成
const app = express();

//リクエストがJSONの場合受け取れるようにする（WPFからはJSONで送信してる）
app.use(express.json());

//在庫API（ルーターのinventory.js）に送る
app.use("/inventory", inventoryRouter);

//サーバー起動
app.listen(3000, () => {
  console.log("Server running on port 3000");
});
