const express = require("express");//Expressの読み込み
const router = express.Router();//ルーター作成
const { getConnection } = require("../db/oracledb");//DB接続の読み込み

//日用品の登録APIとSQL（POST)　※非同期処理宣言
router.post("/", async (req, res) => {

    //req.body=WPFが送ったデータ取得
    const { name, stock } = req.body;

    //入力チェック（name,stockがあるか、初期在庫が0以上か）
    if (!name || stock == null || stock < 0) {
        return res.status(400).json({ message: "不正な入力です" });
    }

    //DB接続用の変数用意
    let conn;
    
    try {
        //DB接続
        conn = await getConnection();
        
        //DB操作文の用意
        const sql = `
        INSERT INTO COMMODITY (name, stock, delete_flag)
        VALUES (:name, :stock, 0)
        `;

        //SQL操作の実行
        await conn.execute(
        sql,
        { name, stock },//インジェクション対策（プレースホルダのあてはめ）
        { autoCommit: true }//自動でINSERTをコミット
        );

        res.status(201).json({ message: "登録成功" });

    } catch (err) {

        //例外が出た場合の処理
        console.error(err);
        res.status(500).json({ message: "サーバーエラー" });

    } finally {

        //DB接続を閉じる
        if (conn) await conn.close();

    }
});


//在庫一覧の取得APIとSQL(GET)　※非同期処理宣言
router.get("/", async (req, res) => {

  //DB接続用の変数用意
  let conn;

  try {
    //DB接続
    conn = await getConnection();

    //SQLの操作文字列用意
    const result = await conn.execute(
      `SELECT commodity_id, name, stock
       FROM COMMODITY
       WHERE delete_flag = 0
       ORDER BY commodity_id`,
       [],
      { outFormat: require("oracledb").OUT_FORMAT_OBJECT }
    );

    //結果をWPFに返す
    res.json(result.rows);

  } catch (err) {

    //例外処理が出た時の処理
    console.error(err);
    res.status(500).json({ message: "DBエラー" });

  } finally {

    //DB接続を閉じる
    if (conn) {
      await conn.close();
    }

  }
});

//日用品の論理削除APIとSQL(PUT)　※非同期処理宣言
router.put("/", async(req, res) => {
  const {id} = req.body;//WPFから取得

  //IDがあるかチェック
  if(!id){
    return res.status(400).json({ message: "IDが不正です" });
  }

  //DB接続用変数
  let conn;

  try{
    //DB接続
    conn = await getConnection();

    //DB文字列作成と実行
    const result = await conn.execute(
    `UPDATE COMMODITY
      SET delete_flag = 1
      WHERE commodity_id = :id`,
      {id: id},//プレースホルダの設定
      { autoCommit: true }//自動コミット
    );

    res.status(200).json({ message: "論理削除しました" });

  }catch(err){
    //例外発生時の処理
    console.error(err);
    res.status(500).json({ message: "削除に失敗しました" });
  }finally{
    //DB接続を閉じる
    if (conn) {
      await conn.close();
    }
  }
});

//日用品の使用／補充APIとSQL(PUT)　※非同期処理宣言
router.put("/stock", async(req, res) => {
  const {id,quantity,operation} = req.body;//WPFから取得

  //ID,quantity,quantityが整数か,operationがあるかチェック
  if (!id || !quantity || quantity <= 0 || !operation) {
    return res.status(400).json({ message: "不正な入力です" });
  }

  //DB接続用変数
  let conn;

  try{
    //DB接続
    conn = await getConnection();

    //SQL文を持つ変数の宣言
    let result;
    
    if(operation === "use"){//使用の場合（減算）

      //SQL文の作成と実行
      result = await conn.execute(
        `UPDATE COMMODITY
         SET stock = stock - :quantity
         WHERE commodity_id = :id
           AND delete_flag = 0
           AND stock >= :quantity`,
        { id, quantity },//プレースホルダの設定
        { autoCommit: true }//自動コミット
      );
      
      //該当データがない場合の処理
      if (result.rowsAffected === 0) {
        return res.status(400).json({ message: "在庫不足です" });
      }

    }else if(operation === "add"){//補充の場合（加算）

      //SQL文の作成と実行
      await conn.execute(
        `UPDATE COMMODITY
         SET stock = stock + :quantity
         WHERE commodity_id = :id
           AND delete_flag = 0`,
        { id, quantity },//プレースホルダの設定
        { autoCommit: true }//自動コミット
      );

    }

    res.json({ message: "在庫を更新しました" });

  }catch(err){
    //例外発生時の処理
    console.error(err);
    res.status(500).json({ message: "在庫操作に失敗しました" });
  }finally{
    //DB接続を閉じる
    if (conn) {
      await conn.close();
    }
  }
});


//ほかのファイルから使えるように外部に公開
module.exports = router;
