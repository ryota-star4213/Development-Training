@echo off
chcp 65001

echo ============================
echo 在庫管理アプリ 起動
echo ============================

REM API 起動
echo [API 起動]
start cmd /k "cd /d API && start_api.bat"

REM 少し待つ（API起動待ち）
timeout /t 3 >nul

REM WPF 起動
echo [WPF 起動]
start cmd /k "cd /d WPF && start_wpf.bat"

echo ============================
echo 起動完了
echo ============================

pause
