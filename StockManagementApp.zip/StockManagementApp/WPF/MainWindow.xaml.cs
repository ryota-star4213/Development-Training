﻿using System.Net.Http;
using System.Threading.Tasks;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using StockManagementApp.Views;

namespace StockManagementApp;

/// <summary>
/// Interaction logic for MainWindow.xaml
/// </summary>
public partial class MainWindow : Window
{
    //コンストラクタ
    public MainWindow()
    {
        InitializeComponent();
        MainContent.Content = new MenuView();//最初にメニュー画面を表示する処理
        // CallApi(); // 起動時にAPI呼び出し（API接続テスト用）
    }

    //画面切り替えメソッド
    public void ChangeView(UserControl view)
    {
        MainContent.Content = view ;//引数で送られてきた画面に切り替える
    }

    //APIとの接続テスト用メソッド
    // private async void CallApi()
    // {
    //     //HTTP通信を行うクラス
    //     using var client = new HttpClient();
    //     try
    //     {
    //         // Node.js WebAPIのURL
    //         string url = "http://localhost:3000/test";

    //         // GETリクエストでAPIを呼ぶ
    //         string response = await client.GetStringAsync(url);//(url)の指定URLにGETリクエストを送る

    //         // 結果をポップアップ表示
    //         MessageBox.Show(response);//APIの返却結果を画面に表示
    //     }
    //     catch (HttpRequestException ex)
    //     {
    //         MessageBox.Show($"API呼び出しに失敗しました: {ex.Message}");
    //     }
    // }
}