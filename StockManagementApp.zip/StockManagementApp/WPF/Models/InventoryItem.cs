using System.Text.Json.Serialization;

namespace StockManagementApp.Models
{
    public class InventoryItem
    {
        [JsonPropertyName("COMMODITY_ID")]
        public int Id { get; set; }

        [JsonPropertyName("NAME")]
        public string Name { get; set; }

        [JsonPropertyName("STOCK")]
        public int Stock { get; set; }
    }
}
