@echo off
chcp 65001

echo ============================
echo WPF アプリ起動
echo ============================

cd /d %~dp0

echo [dotnet run 実行]
dotnet run

pause
