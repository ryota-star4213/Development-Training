using System.Windows;
using System.Windows.Controls;

namespace StockManagementApp.Views;

//partialにより複数で成り立つクラスの宣言
public partial class MenuView : UserControl//UserControlを継承
{
    //コンストラクタ
    public MenuView()
    {
        InitializeComponent();//Menu.xaml(UI)の読み込み
    }

    //在庫一覧ボタンクリック時の画面遷移処理メソッド
    public void Click_InventoryView(object sender, RoutedEventArgs e)
    {   
        //アプリ内の画面表示の箱（MainWIndow）を取得
        MainWindow mainWindow = (MainWindow)Application.Current.MainWindow;

        //画面表示の箱（MainWIndow）のメソッドで画面遷移
        mainWindow.ChangeView(new InventoryView());
    }

    //日用品登録ボタンクリック時の画面遷移処理メソッド
    public void Click_RegistrationView(object sender, RoutedEventArgs e)
    {
        MainWindow mainWindow = (MainWindow)Application.Current.MainWindow;
        mainWindow.ChangeView(new RegistrationView());
    }
}
