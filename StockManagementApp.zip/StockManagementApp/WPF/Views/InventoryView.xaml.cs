using System.Windows;
using StockManagementApp.Models; 
using System.Windows.Controls;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Windows.Documents;

namespace StockManagementApp.Views;

//partialにより複数で成り立つクラスの宣言
public partial class InventoryView : UserControl//UserControlを継承
{
    //コンストラクタ
    public InventoryView()
    {
        InitializeComponent();//InventoryView.xamlの読み込み
        _ = LoadInventory(); // 在庫一覧取得メソッド
    } 
    
    //メニューへ戻るボタンクリック時の画面遷移処理
    public void Click_MenuView(object sender, RoutedEventArgs e)
    {
        MainWindow mainWindow = (MainWindow)Application.Current.MainWindow;
        mainWindow.ChangeView(new MenuView());
    }

    //削除ボタンクリック時の処理(API呼び出し)
    public async void Click_DeleteInventory(object sender, RoutedEventArgs e)
    {
        //未選択をはじく
        if (InventoryDataGrid.SelectedItem == null)
        {
            MessageBox.Show("削除する商品を選択してください");
            return;
        }

        //選択された日用品（行）を取得
        InventoryItem selectedItem =(InventoryItem)InventoryDataGrid.SelectedItem;

        //確認ダイアログ
        MessageBoxResult result = MessageBox.Show(
            $"{selectedItem.Name} を削除しますか？","確認",//メッセージとタイトル
            MessageBoxButton.YesNo,//ボタンのパターン
            MessageBoxImage.Warning//アイコン表示
        );

        //いいえを選んだ場合削除処理終了させる
        if(result != MessageBoxResult.Yes)
        {
            return;
        }
        //はいを押したときの処理（論理削除実行）

        var deleteData = new
        {
            id = selectedItem.Id
        };

        //JSON文字列に変換（WebAPIはJSONデータで受け取るから必要）
        var json = JsonSerializer.Serialize(deleteData);

        //WebAPIへ送信準備（データの準備）
        var content = new StringContent(json, Encoding.UTF8, "application/json");

        //HTTP通信をするためのクラス生成
        using var client = new HttpClient();
        try
        {
            //指定のURLにリクエストを送り、レスポンス結果を取得
            //aweitにより非同期処理を実行
            var response = await client.PutAsync("http://localhost:3000/inventory",content);

            //レスポンス結果を確認して分岐処理
            if (response.IsSuccessStatusCode)
            {
                await LoadInventory();
                MessageBox.Show($"{selectedItem.Name}を削除しました");
            }
            else
            {
                MessageBox.Show("削除に失敗しました");
            }
        }catch
        {
            MessageBox.Show("通信エラーが発生しました");
        }

    }
        
    //実行ボタン（使用／補充）クリック時の処理(API呼び出し)
    private async void Click_Execute(object sender, RoutedEventArgs e)
    {
        //選択された日用品（行）を取得
        var selectedItem = InventoryDataGrid.SelectedItem as InventoryItem;

        //未選択をはじく処理
        if (selectedItem == null)
        {
            MessageBox.Show("商品を選択してください");
            return;
        }

        //数量チェック
        if (!int.TryParse(QuantityTextBox.Text, out int quantity) || quantity <= 0)
        {
            MessageBox.Show("正しい数量を入力してください");
            return;
        }

        //操作選択確認処理
        var comboItem = OperationComboBox.SelectedItem as ComboBoxItem;
        if (comboItem == null)
        {
            MessageBox.Show("使用 / 補充 を選択してください");
            return;
        }

        string operation = comboItem.Content.ToString();

        //在庫の更新処理（使用と補充それぞれ）
        if (operation == "使用")
        {
            //在庫より数量が多い場合はじく
            if (selectedItem.Stock < quantity)
            {
                MessageBox.Show("在庫が不足しています");
                return;
            }
            operation = "use";
        }
        else if (operation == "補充")
        {
            operation = "add";

        }

        //APIに送信するデータの作成
        var stockData = new
        {
            id = selectedItem.Id,
            quantity,
            operation

        };

        //JSON文字列に変換（WebAPIはJSONデータで受け取るから必要）
        var json = JsonSerializer.Serialize(stockData);

        //WebAPIへ送信準備（データの準備）
        var content = new StringContent(json, Encoding.UTF8, "application/json");

        //HTTP通信をするためのクラス生成
        using var client = new HttpClient();
        try
        {
            //指定のURLにリクエストを送り、レスポンス結果を取得
            //aweitにより非同期処理を実行
            var response = await client.PutAsync("http://localhost:3000/inventory/stock",content);

            //レスポンス結果を確認して分岐処理
            if (response.IsSuccessStatusCode)
            {
                await LoadInventory();
                MessageBox.Show("在庫を更新しました");
            }
            else
            {
                MessageBox.Show("在庫の更新に失敗しました");
            }
        }catch
        {
            MessageBox.Show("通信エラーが発生しました");
        }
    }

    //在庫一覧取得（API呼びだし）　※非同期処理宣言
    private async Task LoadInventory()
    {
        //APIにリクエストを送る　※非同期処理
        using var client = new HttpClient();
        try
        {
            var response = await client.GetAsync("http://localhost:3000/inventory");

            //結果の確認
            if (response.IsSuccessStatusCode)
            {
                //レスポンスのJSONをstringとして読む　※非同期処理
                var json = await response.Content.ReadAsStringAsync();

                //C#で使えるようにオブジェクトに変換（List<InventoryItem>化）
                var items = JsonSerializer.Deserialize<List<InventoryItem>>(json);

                //在庫一覧に格納
                InventoryDataGrid.ItemsSource = items;
            }
            else
            {
                MessageBox.Show("在庫一覧の取得に失敗しました");
            }
        }catch
        {
            MessageBox.Show("通信エラーが発生しました");
        }
        
    }

}