using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;


namespace StockManagementApp.Views;

//partialにより複数で成り立つクラスの宣言
public partial class RegistrationView : UserControl//UserControlの継承（これにより）
{
    //コンストラクタ
    public RegistrationView()
    {
        InitializeComponent();//RegistrationView.xamlの読み込み
    }

    //メニューへ戻るボタンクリック時の画面遷移処理
    public void Click_MenuView(object sender, RoutedEventArgs e)
    {
        MainWindow mainWindow = (MainWindow)Application.Current.MainWindow;
        mainWindow.ChangeView(new MenuView());
    }

    //登録ボタンクリック時の処理（API呼び出し）※asyncで非同期処理宣言
    public async void Click_RegistrationInventory(object sender, RoutedEventArgs e)
    {
        //空白をはじく処理
        if (string.IsNullOrWhiteSpace(NameTextBox.Text))
        {
            MessageBox.Show("日用品を入力してください");
            return;
        }

        //数字以外（int型に変換できない場合）と負の数をはじく処理
        if (!int.TryParse(QuantityTextBox.Text, out int quantity) || quantity < 0)
        {
            MessageBox.Show("正しい在庫数を入力してください");
            return;
        }

        //APIに送るデータの作成
        var item = new
        {
            name = NameTextBox.Text,//日用品名
            stock = quantity        //初期在庫
        };

        //JSON文字列に変換（WebAPIはJSONデータで受け取るから必要）
        var json = JsonSerializer.Serialize(item);

        //WebAPIへ送信準備（データの準備）
        var content = new StringContent(json, Encoding.UTF8, "application/json");

        //HTTP通信をするためのクラス生成
        using var client = new HttpClient();
        
        //指定のURLにリクエストを送り、レスポンス結果を取得
        //aweitにより非同期処理を実行
        var response = await client.PostAsync(
            "http://localhost:3000/inventory",
            content
        );

        //レスポンス結果を確認して分岐処理
        if (response.IsSuccessStatusCode)
        {
            MessageBox.Show("日用品を登録しました");
        }
        else
        {
            MessageBox.Show("登録に失敗しました");
        }
    }
}